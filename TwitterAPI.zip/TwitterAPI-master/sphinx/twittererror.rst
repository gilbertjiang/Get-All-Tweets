TwitterAPI.TwitterError
===========================

.. automodule:: TwitterAPI.TwitterError
    :members:
    :undoc-members:
